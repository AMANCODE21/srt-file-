import React, { createContext, useContext, useState } from 'react';
import { Theme, ThemeContextType } from '../types';

const darkTheme: Theme = {
  background: '#1a1a1a',
  text: '#ffffff',
  primary: '#2d2d2d',
  secondary: '#3d3d3d',
  accent: '#6366f1',
};

const lightTheme: Theme = {
  background: '#ffffff',
  text: '#1a1a1a',
  primary: '#f3f4f6',
  secondary: '#e5e7eb',
  accent: '#4f46e5',
};

const ThemeContext = createContext<ThemeContextType>({
  isDark: true,
  toggleTheme: () => {},
  theme: darkTheme,
});

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isDark, setIsDark] = useState(true);
  const theme = isDark ? darkTheme : lightTheme;

  const toggleTheme = () => setIsDark(!isDark);

  return (
    <ThemeContext.Provider value={{ isDark, toggleTheme, theme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
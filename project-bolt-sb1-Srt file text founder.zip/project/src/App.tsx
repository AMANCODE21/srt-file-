import React, { useState, useCallback, useMemo } from 'react';
import { FileUploader } from './components/FileUploader';
import { SearchBar } from './components/SearchBar';
import { FileColumn } from './components/FileColumn';
import { FileData } from './types';
import { parseSRT } from './utils/srtParser';
import { ThemeProvider, useTheme } from './context/ThemeContext';

function AppContent() {
  const [files, setFiles] = useState<FileData[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { theme } = useTheme();

  const handleFilesSelected = useCallback(async (selectedFiles: File[]) => {
    const processedFiles = await Promise.all(
      selectedFiles.map(async (file) => {
        const content = await file.text();
        return {
          name: file.name,
          content: parseSRT(content),
          matches: 0
        };
      })
    );
    setFiles(processedFiles);
  }, []);

  // Debounce search to avoid excessive updates
  const handleSearch = useCallback((term: string) => {
    setSearchTerm(term);
    if (!term) {
      setFiles(files => files.map(file => ({ ...file, matches: 0 })));
      return;
    }

    // Create regex once outside the loop
    const searchRegex = new RegExp(`\\b${term}\\b`, 'gi');
    
    setFiles(files => files.map(file => {
      // Process matches in chunks to avoid blocking the main thread
      const matches = file.content.reduce((count, entry) => {
        const matches = (entry.text.match(searchRegex) || []).length;
        return count + matches;
      }, 0);
      return { ...file, matches };
    }));
  }, []);

  // Memoize total matches calculation
  const totalMatches = useMemo(() => 
    files.reduce((sum, file) => sum + file.matches, 0),
    [files]
  );

  // Memoize file columns to prevent unnecessary re-renders
  const fileColumns = useMemo(() => 
    files.map((file, index) => (
      <div 
        key={`file-column-${index}`}
        className="h-[calc(100vh-8rem)] bg-opacity-5 bg-white rounded-lg overflow-hidden"
      >
        <FileColumn
          file={file}
          searchTerm={searchTerm}
          columnIndex={index}
        />
      </div>
    )),
    [files, searchTerm]
  );

  return (
    <div 
      className="min-h-screen"
      style={{ backgroundColor: theme.background }}
    >
      <div className="sticky top-0 z-20">
        <SearchBar 
          searchTerm={searchTerm}
          totalMatches={totalMatches}
          onSearch={handleSearch}
        />
      </div>
      
      {files.length === 0 ? (
        <div className="container mx-auto p-8">
          <FileUploader onFilesSelected={handleFilesSelected} />
        </div>
      ) : (
        <div className="p-4">
          <div className="grid grid-cols-5 gap-4 auto-rows-fr">
            {fileColumns}
          </div>
        </div>
      )}
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;
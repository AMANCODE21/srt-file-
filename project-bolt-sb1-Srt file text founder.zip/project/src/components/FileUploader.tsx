import React, { useCallback } from 'react';
import { Upload } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface FileUploaderProps {
  onFilesSelected: (files: File[]) => void;
}

export const FileUploader: React.FC<FileUploaderProps> = ({ onFilesSelected }) => {
  const { theme } = useTheme();

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files).filter(file => file.name.endsWith('.srt'));
    if (files.length > 29) {
      alert('Maximum 29 files allowed');
      return;
    }
    onFilesSelected(files);
  }, [onFilesSelected]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files ? Array.from(e.target.files).filter(file => file.name.endsWith('.srt')) : [];
    if (files.length > 29) {
      alert('Maximum 29 files allowed');
      return;
    }
    onFilesSelected(files);
  }, [onFilesSelected]);

  return (
    <div 
      className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer"
      style={{ 
        borderColor: theme.accent,
        backgroundColor: theme.primary,
        color: theme.text 
      }}
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
    >
      <input
        type="file"
        multiple
        accept=".srt"
        onChange={handleFileInput}
        className="hidden"
        id="file-input"
      />
      <label htmlFor="file-input" className="cursor-pointer">
        <Upload className="w-12 h-12 mx-auto mb-4" style={{ color: theme.accent }} />
        <p className="text-lg mb-2">Drop your .srt files here</p>
        <p className="text-sm opacity-60">or click to select files (max 29)</p>
      </label>
    </div>
  );
};
import React from 'react';
import { Search } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

interface SearchBarProps {
  searchTerm: string;
  totalMatches: number;
  onSearch: (term: string) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({ searchTerm, totalMatches, onSearch }) => {
  const { theme, isDark, toggleTheme } = useTheme();

  return (
    <div 
      className="flex items-center gap-4 p-4 border-b sticky top-0 z-10"
      style={{ 
        backgroundColor: theme.background,
        borderColor: theme.secondary
      }}
    >
      <div className="flex-1 relative">
        <Search 
          className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5" 
          style={{ color: theme.text }}
        />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearch(e.target.value)}
          className="w-full pl-10 pr-4 py-2 rounded-lg"
          style={{ 
            backgroundColor: theme.primary,
            color: theme.text,
            border: `1px solid ${theme.secondary}`
          }}
          placeholder="Search across all files..."
        />
      </div>
      <div className="flex items-center gap-4">
        <span style={{ color: theme.text }}>
          Total matches: <strong>{totalMatches}</strong>
        </span>
        <button
          onClick={toggleTheme}
          className="px-4 py-2 rounded-lg"
          style={{ 
            backgroundColor: theme.accent,
            color: theme.text
          }}
        >
          {isDark ? 'Light Mode' : 'Dark Mode'}
        </button>
      </div>
    </div>
  );
};
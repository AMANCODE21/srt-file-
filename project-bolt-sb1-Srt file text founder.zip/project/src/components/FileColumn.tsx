import React, { useRef, useCallback, useMemo } from 'react';
import { ChevronUp, ChevronDown } from 'lucide-react';
import { FileData } from '../types';
import { useTheme } from '../context/ThemeContext';

interface FileColumnProps {
  file: FileData;
  searchTerm: string;
  columnIndex: number;
}

export const FileColumn: React.FC<FileColumnProps> = React.memo(({ file, searchTerm, columnIndex }) => {
  const columnRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const { theme } = useTheme();

  const scrollToNextMatch = useCallback((direction: 'up' | 'down') => {
    if (!contentRef.current) return;
    
    const highlights = contentRef.current.querySelectorAll('.highlight');
    if (!highlights.length) return;

    const container = contentRef.current;
    const containerRect = container.getBoundingClientRect();
    const currentScroll = container.scrollTop;
    let targetElement: Element | null = null;

    if (direction === 'down') {
      for (const highlight of highlights) {
        const rect = highlight.getBoundingClientRect();
        const relativeTop = rect.top - containerRect.top;
        if (relativeTop > 100) {
          targetElement = highlight;
          break;
        }
      }
      if (!targetElement) targetElement = highlights[0];
    } else {
      for (let i = highlights.length - 1; i >= 0; i--) {
        const rect = highlights[i].getBoundingClientRect();
        const relativeTop = rect.top - containerRect.top;
        if (relativeTop < -100) {
          targetElement = highlights[i];
          break;
        }
      }
      if (!targetElement) targetElement = highlights[highlights.length - 1];
    }

    if (targetElement) {
      const targetRect = targetElement.getBoundingClientRect();
      const targetRelativeTop = targetRect.top - containerRect.top;
      container.scrollTop = currentScroll + targetRelativeTop - 100;
    }
  }, []);

  // Memoize search regex creation
  const searchRegex = useMemo(() => 
    searchTerm ? new RegExp(`(${searchTerm})`, 'gi') : null,
    [searchTerm]
  );

  // Memoize content rendering with improved key generation
  const renderedContent = useMemo(() => {
    let matchCounter = 0;
    
    return file.content.map((entry) => {
      const parts = searchTerm && searchRegex ? 
        entry.text.split(searchRegex) :
        [entry.text];
      
      const highlightedText = parts.map((part, index) => {
        const isMatch = searchTerm && part.toLowerCase() === searchTerm.toLowerCase();
        // Generate a truly unique key using multiple unique identifiers
        const uniqueKey = `${file.name}-${columnIndex}-${entry.id}-${index}-${isMatch ? `match-${matchCounter++}` : 'text'}`;
        
        return isMatch ? 
          <span key={uniqueKey} className="highlight bg-yellow-500 text-black">{part}</span> : 
          <span key={uniqueKey}>{part}</span>;
      });

      return (
        <div key={`${file.name}-${columnIndex}-entry-${entry.id}`} className="mb-4">
          <div className="text-sm opacity-60">{entry.startTime} → {entry.endTime}</div>
          <div className="mt-1">{highlightedText}</div>
        </div>
      );
    });
  }, [file.name, file.content, searchTerm, searchRegex, columnIndex]);

  return (
    <div 
      ref={columnRef}
      className="flex flex-col h-full border-r"
      style={{ backgroundColor: theme.primary, borderColor: theme.secondary }}
    >
      <div className="flex items-center justify-between p-2 border-b sticky top-0 z-10" 
        style={{ 
          borderColor: theme.secondary,
          backgroundColor: theme.primary 
        }}
      >
        <div className="flex-1 truncate" style={{ color: theme.text }}>{file.name}</div>
        <div className="flex items-center gap-2">
          <span className="text-sm" style={{ color: theme.accent }}>{file.matches} matches</span>
          <button 
            onClick={() => scrollToNextMatch('up')}
            className="p-1 rounded hover:bg-opacity-20 hover:bg-white"
          >
            <ChevronUp className="w-4 h-4" style={{ color: theme.text }} />
          </button>
          <button 
            onClick={() => scrollToNextMatch('down')}
            className="p-1 rounded hover:bg-opacity-20 hover:bg-white"
          >
            <ChevronDown className="w-4 h-4" style={{ color: theme.text }} />
          </button>
        </div>
      </div>
      <div 
        ref={contentRef}
        className="flex-1 overflow-y-auto p-4"
        style={{ color: theme.text }}
      >
        {renderedContent}
      </div>
    </div>
  );
});
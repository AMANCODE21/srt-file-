export interface SubtitleEntry {
  id: number;
  startTime: string;
  endTime: string;
  text: string;
}

export interface FileData {
  name: string;
  content: SubtitleEntry[];
  matches: number;
}

export interface Theme {
  background: string;
  text: string;
  primary: string;
  secondary: string;
  accent: string;
}

export interface ThemeContextType {
  isDark: boolean;
  toggleTheme: () => void;
  theme: Theme;
}
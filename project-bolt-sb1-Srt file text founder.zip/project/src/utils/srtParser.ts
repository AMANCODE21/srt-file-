import { SubtitleEntry } from '../types';

export function parseSRT(content: string): SubtitleEntry[] {
  const blocks = content.trim().split(/\n\s*\n/);
  return blocks.map((block) => {
    const [id, timeCode, ...textLines] = block.split('\n');
    const [timeRange] = timeCode.split(' --> ');
    const [endTime] = timeCode.split(' --> ')[1] || [timeRange];
    
    return {
      id: parseInt(id),
      startTime: timeRange.trim(),
      endTime: endTime.trim(),
      text: textLines.join(' ').trim(),
    };
  });
}

export function findExactMatches(text: string, searchTerm: string): number[] {
  const indices: number[] = [];
  let index = 0;
  
  while (true) {
    index = text.indexOf(searchTerm, index);
    if (index === -1) break;
    
    const beforeChar = index > 0 ? text[index - 1] : ' ';
    const afterChar = index + searchTerm.length < text.length 
      ? text[index + searchTerm.length] 
      : ' ';
      
    if (!/[a-zA-Z0-9]/.test(beforeChar) && !/[a-zA-Z0-9]/.test(afterChar)) {
      indices.push(index);
    }
    index += searchTerm.length;
  }
  
  return indices;
}